package com.example.myandroid;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends ActionBarActivity implements OnClickListener {

	private Button bcTest;
	private Button sayHello;
	
	private EditText msg;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        msg = (EditText) findViewById(R.id.inputmsg);
        bcTest = (Button) findViewById(R.id.broadcasttest);
        sayHello = (Button) findViewById(R.id.sayhello);
        
        sayHello.setOnClickListener(this);
        bcTest.setOnClickListener(this);
        Log.v("hello", "abc");
        Log.v("test", "abc");
        
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (v == bcTest) {
			Intent it = new Intent();
			it.setAction("com.myandroid.receiver.broadcast.test");
			sendBroadcast(it);
		} else if (v == sayHello) {
			Toast.makeText(this, "Hello " + msg.getText().toString(), Toast.LENGTH_LONG).show();
		}
	}
}
